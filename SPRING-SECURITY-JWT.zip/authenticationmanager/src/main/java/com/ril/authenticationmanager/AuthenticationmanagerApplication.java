package com.ril.authenticationmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthenticationmanagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthenticationmanagerApplication.class, args);
	}

}
